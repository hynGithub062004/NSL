RAN mô phỏng; Core được đo trong cửa sổ riêng, không suy ra E2E latency.
Core historical KPI không dùng trong kết quả này.
